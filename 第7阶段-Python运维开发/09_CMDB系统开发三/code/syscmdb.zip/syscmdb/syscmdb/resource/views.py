from django.shortcuts import render
from django.views.generic import ListView, TemplateView, View
from resource.models import *
from django.http import JsonResponse
import json


# Create your views here.

class IdcListView(ListView):
    template_name = 'idc_list.html'
    model = Idc


class IdcAddView(TemplateView):
    template_name = 'idc_add.html'

    def post(self, request):
        data = request.POST
        res = {'status': 0, 'msg': '添加机房成功'}
        # 收集用户信息并入库
        try:
            Idc.objects.create(
                name=data.get('name'),
                name_cn=data.get('name_cn'),
                address=data.get('address'),
                phone=data.get('phone'),
                username=data.get('username'),
                username_email=data.get('username_email'),
                username_phone=data.get('username_phone'))
        except Exception as e:
            print(e)
            res = {'status': 1, 'msg': '添加机房失败'}
        return JsonResponse(res)


class IdcUpdateView(TemplateView):
    template_name = 'idc_update.html'

    def get_context_data(self, **kwargs):
        context = super(IdcUpdateView, self).get_context_data(**kwargs)
        context['idc_obj'] = Idc.objects.get(id=self.request.GET.get('id'))
        return context

    def post(self, request):
        data = request.POST
        res = {'status': 0, 'msg': '修改机房信息成功'}
        # 收集用户信息并修改
        try:
            Idc.objects.filter(id=request.POST.get('id')).update(
                name=data.get('name'),
                name_cn=data.get('name_cn'),
                address=data.get('address'),
                phone=data.get('phone'),
                username=data.get('username'),
                username_email=data.get('username_email'),
                username_phone=data.get('username_phone'))
        except Exception as e:
            print(e)
            res = {'status': 1, 'msg': '修改机房信息失败'}
        return JsonResponse(res)


class IdcDeleteView(View):
    def post(self, request):
        res = {'status': 0, 'msg': '删除机房成功'}
        # 接收信息
        try:
            Idc.objects.get(id=request.POST.get('id')).delete()
        except Exception as e:
            print(e)
            res = {'status': 1, 'msg': '删除机房失败'}
        return JsonResponse(res)


class ServerUserListView(ListView):
    template_name = 'serveruser_list.html'
    model = ServerUser


class ServerUserAddView(TemplateView):
    template_name = 'serveruser_add.html'

    def post(self, request):
        data = request.POST
        res = {'status': 0, 'msg': '创建服务器用户成功'}
        # 收集用户信息并入库
        try:
            ServerUser.objects.create(
                name=data.get('name'),
                username=data.get('username'),
                password=data.get('password'),
                info=data.get('info')
            )
        except Exception as e:
            print(e)
            res['status'] = 1
            res['msg'] = '创建服务器用户失败'
        return JsonResponse(res)


class ServerUserUpdateView(TemplateView):
    template_name = 'serveruser_update.html'

    def get_context_data(self, **kwargs):
        context = super(ServerUserUpdateView, self).get_context_data(**kwargs)
        context['serveruser_obj'] = ServerUser.objects.get(id=self.request.GET.get('id'))
        return context

    def post(self, request):
        data = request.POST
        res = {'status': 0, 'msg': '修改服务器用户信息成功'}
        # 收集用户信息并修改
        try:
            ServerUser.objects.filter(id=request.POST.get('id')).update(
                name=data.get('name'),
                username=data.get('username'),
                password=data.get('password'),
                info=data.get('info'))
        except Exception as e:
            print(e)
            res = {'status': 1, 'msg': '修改服务器用户信息失败'}
        return JsonResponse(res)


class ServerUserDeleteView(View):
    def post(self, request):
        # print(request.POST)
        res = {'status': 0, 'msg': '删除服务器用户成功'}
        # 接收用户数据 操作数据
        try:
            ServerUser.objects.get(id=request.POST.get('id')).delete()
        except Exception as e:
            print(e)
            res = {'status': 1, 'msg': '删除服务器用户失败'}
        return JsonResponse(res)


class ServerListView(ListView):
    template_name = 'server_list.html'
    model = Server


class ServerDataApi(View):
    def get(self, request):
        data = request.GET
        res = {'status': '0', 'msg': 'ok'}
        for one in data:
            sysinfo = one
        sysinfo = json.loads(sysinfo)
        # # 判断uuid是否存在数据库中 如果存在就删除信息
        # # 删除主机信息
        # try:
        #     serverOBJ = Server.objects.get(uuid=sysinfo['uuid'])
        #     serverOBJ.delete()
        # except Exception as e:
        #     serverOBJ = Server.objects.get(uuid=sysinfo['uuid'])
        # # 删除硬盘  网卡关联信息
        # serverOBJ.network_set.all().delete()
        # serverOBJ.disk_set.all().delete()
        # 添加主机信息
        server_obj = Server()
        server_obj.hostname = sysinfo['hostname']
        server_obj.cpu_info = sysinfo['cpu_info']
        server_obj.cpu_count = sysinfo['cpu_count']
        server_obj.mem_info = sysinfo['mem_info']
        server_obj.os_system = sysinfo['os_system']
        server_obj.os_system_num = sysinfo['os_system_num']
        server_obj.uuid = sysinfo['uuid']
        server_obj.sn = sysinfo['sn']
        server_obj.scan_status = 1
        server_obj.save()
        # 添加网卡信息
        ip_info = sysinfo['ip_info']
        for key, value in ip_info.items():
            # print(key+':'+value)
            NetWork.objects.create(
                name=key,
                ip_address=value,
                server=server_obj
            )
        # 硬盘
        disk_info = sysinfo['disk_info']
        for key, value in disk_info.items():
            # print(key+':'+value)
            Disk.objects.create(
                name=key,
                size=value,
                server=server_obj
            )
        return JsonResponse(res)

class cleartableView(View):
    def get(self,request):
        Server.objects.all().delete()