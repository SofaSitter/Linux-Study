from django.apps import AppConfig


class ResourceConfig(AppConfig):
    name = 'resource'
