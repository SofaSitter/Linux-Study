from django.shortcuts import render, HttpResponse
from django.views.generic import View, TemplateView
from django.http import JsonResponse
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect
from django.urls import reverse


# Create your views here.

class BaseView(View):
    def get(self, request):
        return render(request, 'base.html')


# class IndexView(View):
#     def get(self,request):
#         return render(request,'index.html')

class IndexView(LoginRequiredMixin,TemplateView):
    template_name = 'index.html'

    def get_context_data(self, **kwargs):
        context = super(IndexView, self).get_context_data(**kwargs)
        context['body'] = '控制台主页'
        return context


class LoginView(TemplateView):
    template_name = 'login.html'

    def post(self, request):
        print(request.POST)
        # 接收用户信息
        username = request.POST.get('username')
        password = request.POST.get('password')
        # 校验用户
        # if username == 'admin' and password == '123456':
        user = authenticate(username=username, password=password)
        if user:
            # 写入session
            login(request,user)
            return JsonResponse({'status': 0, 'msg': '登录成功'})
        else:
            return JsonResponse({'status': 1, 'msg': '用户名称或者密码错误'})

class LogoutView(View):
    def get(self,request):
        # 清空session
        logout(request)
        return HttpResponseRedirect(reverse('user_login'))